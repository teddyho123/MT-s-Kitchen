Does jsx file have to be Capitalize?

10-28-2024
Decided on using Docker for packaging.
Decided on using FastAPI for backend.
Decided on using React via Vite for frontend.
Created framework.
Laid out the each webpages function.

10-29-2024
Created jsx files for each webpage.
