import { ChakraProvider } from "@/components/ui/provider"

function Homepage() {
  

    return (
      <>
        <h1>Homepage</h1>
      </>
    )
  }
  
  export default Homepage