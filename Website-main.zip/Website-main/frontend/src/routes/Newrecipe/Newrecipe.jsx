function Newrecipe() {
  

    return (
      <>
        <h1>New Recipe</h1>
      </>
    )
  }
  
  export default Newrecipe